<?php
 include_once('notas.php');
 include_once('notasCollector.php');
 $notasCollectorObj = new notasCollector();
 $max = $notasCollectorObj->selectMax();
 $max=($max+1);
?>
<!DOCTYPE html>
 <html lang="es">
  <head>
   <meta charset ="utf-8">
   <title> Nueva Nota </title>
  </head>
  <body>
   <?php //echo $max; ?>
    <form action ="insertar_nota.php" method ="post">
     <fieldset>
      <label> ID </label>
      <input type="text" name= "ID" value = "<?php echo $max; ?>" /> </br>
      <label> Parcial</label>
      <input type="text" name= "parcial" value = ""/> </br>
      <label> Final</label>
      <input type="text" name= "finall" value = ""/></br>
      <label> Mejoramiento</label>
      <input type="text" name= "mejoramiento" value = ""/></br>
      <label> Promedio</label>
      <input type="text" name= "nota_prom" value = ""/></br>
      <button type = "submit"> ACEPTAR </button>
      
     </fieldset>
    </form> 
  </body>
 </html>
