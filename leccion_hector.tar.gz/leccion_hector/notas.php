<?php

class notas
{
    private $idnotas;
    private $parcial;
    private $finall;
    private $mejoramiento;
    private $nota_prom;


    function __construct($idnotas, $parcial, $finall, $mejoramiento, $nota_prom) {
       $this->idnotas = $idnotas;
       $this->parcial = $parcial;
       $this->finall = $finall;
       $this->mejoramiento = $mejoramiento;
       $this->nota_prom = $nota_prom;
     }

     function __nota_prom($parcial, $finall, $mejoramiento){
       if($parcial > $finall){
	 if($finall > $mejoramiento){
	   $nota_prom=(($parcial+$final)/2);
         }else{
           $nota_prom=(($parcial+$mejoramiento)/2);
         }
       }else{
         if($parcial > $mejoramiento){
	   $nota_prom=(($parcial+$final)/2);
         }else{
           $nota_prom=(($finall+$mejoramiento)/2);
         }
       }
     }
    
     function setIdNotas($idnotas){
       $this->idnotas = $idnotas;
     }
 
     function getIdNotas(){
       return $this->idnotas;
     } 

     function setParcial($parcial){
       $this->parcial = $parcial;
     } 

     function getParcial(){
       return $this->parcial;
     } 

     function setFinall($finall){
       $this->finall = $finall;
     } 

     function getFinall(){
       return $this->finall;
     } 
  
     function setMejoramiento($mejoramiento){
       $this->mejoramiento = $mejoramiento;
     } 

     function getMejoramiento(){
       return $this->mejoramiento;
     } 

     function getPromedio(){
       return $this->nota_prom;
     } 
	
}

?> 
