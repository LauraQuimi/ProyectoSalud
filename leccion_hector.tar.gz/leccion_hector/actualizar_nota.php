<?php
 include_once('notasCollector.php');
 $id = $_POST['ID'];
 $parcial = $_POST['parcial'];
 $final = $_POST['final'];
 $mejoramiento = $_POST['mejoramiento'];
 $nota_prom = $_POST['nota_prom'];
 $notasCollectorObj = new notasCollector();
 $notasCollectorObj->updateDemo($parcial, $final, $mejoramiento);

?>
