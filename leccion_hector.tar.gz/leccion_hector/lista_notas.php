<?php
include_once("notasCollector.php");
//$id =1;
$notasCollectorObj = new notasCollector();
?>
<a href="nueva_nota.php">Ingresar Nota</a>
<table border=1>
  <th>
    <td>PARCIAL</td>
    <td>FINAL</td>
    <td>MEJORAMIENTO</td>
    <td>PROMEDIO</td>
    <td colspan = 2>OPCIONES</td>
  </th>
<?php
foreach ($notasCollectorObj->showNotas() as $c){
?>
  <tr>
     <td><?php echo $c->getIdnotas() ?></td>
     <td><?php echo $c->getParcial() ?></td>
     <td><?php echo $c->getFinall() ?></td>
     <td><?php echo $c->getMejoramiento() ?></td>
     <td><?php echo $c->getPromedio() ?></td>
     <td><a href="editar_nota.php?id=<?php echo $c->getIdNotas() ?>">Editar</a></td>
     <td><a href="eliminar_nota.php?id=<?php echo $c->getIdNotas() ?>">Eliminar</a></td>
  </tr>
<?php  
}
?>
</table>
