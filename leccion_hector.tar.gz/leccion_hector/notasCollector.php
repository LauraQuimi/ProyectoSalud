<?php

include_once('notas.php');
include_once('Collector.php');

class notasCollector extends Collector
{
  
  function showNotas() {
    $rows = self::$db->getRows("SELECT * FROM notas ");        
    $arrayNotas= array();        
    foreach ($rows as $c){
      $aux = new notas($c{'idnotas'},$c{'parcial'},$c{'final'},$c{'mejoramiento'},$c{'nota_prom'});
      array_push($arrayNotas, $aux);
    }
    return $arrayNotas;        
  }
 
  function showNota($idnotas) {
    $row = self::$db->getRow("SELECT * FROM notas where idnotas = $idnotas");   
    //print_r ($row);     
    $notas = new notas($row{'idnotas'},$row{'parcial'},$row{'final'},$row{'mejoramiento'},$row{'nota_prom'});
    return $notas;        
  }

  function updateNotas($id, $parcial, $finall, $mejoramiento) {
    $update = self::$db->updateRow("Update notas set parcial=$nombre, final=$final, mejoramiento=$mejoramiento where iddemo=$id");             
  }

  function deleteNotas($id) {
    $delete = self::$db->deleteRow("Delete from notas where idnotas=$idnotas");             
  }

  function insertNotas($parcial, $finall, $mejoramiento, $nota_prom) {
    $new_row = self::$db->insertRow("Insert into notas (parcial, final, mejoramiento, nota_prom) values ($parcial,$finall,$mejoramiento,$nota_prom)");             
  }

  function selectMax() {
    $row = self::$db->getRow("SELECT MAX(idnotas) from notas");  
    $max = $row{'max'};
    return $max;        
  }

}
?>

