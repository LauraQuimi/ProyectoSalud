<?php
 include_once('notasCollector.php');
 $id = $_GET['idnotas']; 
 $notasCollectorObj = new notasCollector();
 $notasCollectorObj->deleteNota($idnotas);

?>
